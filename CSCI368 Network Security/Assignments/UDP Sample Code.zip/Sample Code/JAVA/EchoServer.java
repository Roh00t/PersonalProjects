import java.net.*;
import java.util.*;
 
 
class EchoServer {
  public static void main( String args[] ) throws Exception {
    DatagramSocket socket = new DatagramSocket(1500);
    DatagramPacket packet = new DatagramPacket(new byte[512],512);
    while ( true ) {
      socket.receive( packet );
      System.out.println( ""+new Date()+" "+packet.getAddress()+":"+packet.getPort()+" "+new String(packet.getData(),0,packet.getLength()) );
      socket.send( packet );
    }
  }
}

import java.net.*;
import java.util.*;
 
 
class EchoClient {
  public static void main( String args[] ) throws Exception {
    DatagramSocket socket = new DatagramSocket();
    socket.setSoTimeout( 5000 );
    byte[] buffer = args[1].getBytes();
    DatagramPacket packet = new DatagramPacket(buffer,buffer.length,InetAddress.getByName(args[0]),1500);
    socket.send( packet );
    Date timeSent = new Date();
    socket.receive( packet );
    Date timeReceived = new Date();
    System.out.println( ""+(timeReceived.getTime()-timeSent.getTime())+" ms "+new String(packet.getData(),0,packet.getLength()) );
  }
}

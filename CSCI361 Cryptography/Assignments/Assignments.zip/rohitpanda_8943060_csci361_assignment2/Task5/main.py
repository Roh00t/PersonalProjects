"""
CSCI361 ASSIGNMENT 2 TASK 5
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

from Crypto.Hash import SHA256
import random

class RingSignature:
    
    @staticmethod
    def read_public_keys():


        """ Reads public keys from publickey.txt """

        try:
            with open("publickey.txt", "r") as f:
                lines = f.readlines()
                keys = [int(line.strip()) for line in lines]
                return keys[0], keys[1], keys[2], keys[3]  # e1, n1, e2, n2
        except Exception as e:
            print(f"Error reading public keys: {e}")
            return None

    @staticmethod
    def read_message():
        """ Reads message from message.txt """


        try:
            with open("message.txt", "r") as f:
                return f.read().strip()
        except Exception as e:
            print(f"Error reading message: {e}")
            return None

    @staticmethod
    def sign(message, signer_id, private_key):
        """ Generates a ring signature """

        # Load public keys


        e1, n1, e2, n2 = RingSignature.read_public_keys()
        
        # Generate encryption key k = Hash(message)

        k = int(SHA256.new(message.encode()).hexdigest(), 16) % 2**16
        
        # Generate random glue value v that's relatively small


        glue = random.randint(2, 100)
        
        if signer_id == 1:
            # For non-signer (user 2)
            x2 = random.randint(1, n2-1)
            y2 = pow(x2, e2, n2)
            
            # For signer (user 1)

            combined = (k * y2) % n1
            y1 = (combined * pow(glue, 1, n1)) % n1
            x1 = pow(y1, private_key, n1)
            
        else:  # signer_id == 2
            # For non-signer (user 1)


            x1 = random.randint(1, n1-1)
            y1 = pow(x1, e1, n1)
            
            # For signer (user 2)
            combined = (k * y1) % n2
            y2 = (combined * pow(glue, 1, n2)) % n2
            x2 = pow(y2, private_key, n2)
        
        # Store signature

        with open("signature.txt", "w") as f:
            f.write(f"{e1} {e2} {glue} {x1} {x2}")
        
        print("Signature generated successfully.")

    @staticmethod
    def verify(message):
        """ Verifies a ring signature """

        # Load public keys


        e1, n1, e2, n2 = RingSignature.read_public_keys()
        
        try:
            with open("signature.txt", "r") as f:
                e1_s, e2_s, glue, x1, x2 = map(int, f.read().split())
        except Exception as e:
            print(f"Error reading signature: {e}")
            return False
        
        # Compute y values

        y1 = pow(x1, e1, n1)
        y2 = pow(x2, e2, n2)
        
        # Generate encryption key k = Hash(message)

        k = int(SHA256.new(message.encode()).hexdigest(), 16) % 2**16
        
        # Verify combined equation for both possible signers


        combined1 = ((k * y2) % n1 * pow(glue, 1, n1)) % n1
        combined2 = ((k * y1) % n2 * pow(glue, 1, n2)) % n2
        
        
        if y1 == combined1 or y2 == combined2:
            print("Verification successful.")
            return True
        else:
            print("Verification failed.")
            return False

def main():
    mode = input("Enter program (sign/verify): ").strip().lower()
    
    if mode == "sign":
        message = RingSignature.read_message()
        if not message:
            return
        
        signer_id = int(input("Enter signer ID (1 or 2): "))
        if signer_id not in [1, 2]:
            print("Error: Invalid signer ID. Must be 1 or 2.")
            return
            
        private_key = int(input("Enter signer's private key: "))
        RingSignature.sign(message, signer_id, private_key)
    
    elif mode == "verify":
        message = RingSignature.read_message()
        if not message:
            return
        
        result = RingSignature.verify(message)
        print(f"Verification: {result}")
    
    else:
        print("Error: Invalid mode. Choose 'sign' or 'verify'.")

if __name__ == "__main__":
    main()
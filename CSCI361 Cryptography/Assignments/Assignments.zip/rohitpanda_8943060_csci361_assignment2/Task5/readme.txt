"""
CSCI361 ASSIGNMENT 2 TASK 5
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
NOTE: cd into Task5 in order for the main.py to work inside the virtual environment

# Task Five. Implementing Ring Signature of 2 users (2 marks)
This program implements a 2-user ring signature scheme using RSA and AES encryption. It consists of two main programs: one for signing messages and another for verifying signatures.

## Features
- RSA-based ring signature implementation
- AES-128 symmetric encryption (10 rounds)
- File-based input/output
- Comprehensive error handling
- Support for 2 users

## Requirements
- Python 3.6+
- pycryptodome library (`pip install pycryptodome`)

## File Structure
The system uses three files:
1. `publickey.txt`: Contains RSA public keys (e1, n1, e2, n2)
2. `message.txt`: Contains the message to be signed
3. `signature.txt`: Contains the generated signature (output of sign program)

## Usage


Alice public key: (5, 21)
Alice private key: (5, 21)
Bob public key: (3, 33)
Bob private key: (7, 33)

### Signing Program
```bash
python main.py
> Enter program (sign/verify): sign
> Enter signer ID (1 or 2): 1
> Enter signer's private key: [private key]
```

### Verification Program
```bash
python main.py
> Enter program (sign/verify): verify
```


OUTPUT:
```bash
Enter program (sign/verify): sign
Enter signer ID (1 or 2): 1
Enter signer's private key: 5
Signature generated successfully.

Enter program (sign/verify): verify
Verification successful.
Verification: True

Enter program (sign/verify): sign
Enter signer ID (1 or 2): 2
Enter signer's private key: 7
Signature generated successfully.

Enter program (sign/verify): verify
Verification successful.
Verification: True
```

## File Formats
### publickey.txt
```
e1
n1
e2
n2
```

### message.txt
```
[message string]
```

### signature.txt
Binary file containing the signature

## Implementation Details
### Ring Signature Structure
1. Random AES key generation
2. Message encryption using AES
3. RSA-based ring signature generation
4. Signature verification using both public keys

### Security Features
- AES-128 encryption with CBC mode
- RSA-based asymmetric encryption
- Random initialization vectors
- Secure padding

## Error Handling
The program handles:
- Invalid input files
- Malformed public keys
- Invalid private keys
- File I/O errors
- Encryption/decryption failures
- Invalid signature format
- Memory limitations

## Security Notes
1. This implementation is for educational purposes
2. Private keys should be securely stored
3. AES key is randomly generated for each signature
4. The implementation uses standard cryptographic libraries

## Performance Considerations
- RSA operations may be slow for large key sizes
- File I/O is performed for each operation
- Memory usage scales with message size

## License
This code is provided for educational purposes only. See LICENSE file for details.
"""
CSCI361 ASSIGNMENT 2 TASK 4
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

# Task Four. Collision Finding of Hash Functions (2 marks)
This program implements a collision finder for a simplified version of SHA-1 (SSHA-1) that uses only 34 bits of the original SHA-1 hash. 
It finds two different dollar amounts that produce identical hash values for similar messages.

## Features
- Implements SSHA-1 (Simplified SHA-1) using first 10 and last 24 bits
- Uses Python's hashlib for SHA-1 calculation
- Finds collisions using birthday attack approach
- Comprehensive error handling
- Progress feedback during search

## Requirements
- Python 3.6+
- hashlib (standard library)
- random (standard library)

## Implementation Details
The program:
1. Uses standard SHA-1 from hashlib
2. Extracts specific bits (first 10 + last 24)
3. Searches for collisions using random sampling
4. Validates all inputs and operations

## Usage
1. Run the program:
```bash
python main.py
```
2. Enter your first name when prompted
3. Wait for the program to find a collision

## Output Format
The program outputs:
1. Two different messages
2. Their common hash value (34 bits)
3. Number of trials needed to find collision

Example output:
```
SSHA-1 Hash Collision Finder
------------------------------

Enter your first name: Rohit

Searching for collision... This may take a while...

Collision found!

Message 1: Mario owes Rohit 45673 dollars
Message 2: Mario owes Rohit 98412 dollars
Hash value: 0000000101101001111110101010101010
Number of trials: 12,345
```

## Error Handling
The program handles:
- Invalid first names
- Memory limitations
- System interruptions
- Hashing failures
- Maximum trials exceeded

## Security Note
This is a demonstration of hash collision finding in a weakened hash function (34 bits only). The original SHA-1 (160 bits) is significantly more collision-resistant, though it has been cryptographically broken.

## Source Attribution
The SHA-1 implementation uses Python's standard library hashlib, which is based on the reference implementation from the NIST Standard. For the original SHA-1 source code, see: https://github.com/clibs/sha1

## Performance Note
The collision search uses a birthday attack approach. With 34 bits, collisions should be found relatively quickly (expected trials ≈ 2^17). Actual performance may vary based on random number generation.

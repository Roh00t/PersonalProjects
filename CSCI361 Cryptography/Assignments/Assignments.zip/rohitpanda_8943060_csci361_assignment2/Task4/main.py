"""
CSCI361 ASSIGNMENT 2 TASK 4
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
import hashlib
import random
from typing import Tuple, Optional

class CollisionFinderError(Exception):
    """Custom exception class for collision finding errors"""
    pass

class SSHAHasher:
    """Simplified SHA-1 hasher that only uses first 10 and last 24 bits"""
    
    def __init__(self, firstname: str):
        """
        Initialize the hasher with user's first name
        
        Args:
            firstname: User's first name
            
        Raises:
            CollisionFinderError: If firstname is invalid
        """
        if not firstname or not isinstance(firstname, str):
            raise CollisionFinderError("First name must be a non-empty string")
        if not firstname.isalpha():
            raise CollisionFinderError("First name must contain only letters")
        self.firstname = firstname

    def generate_message(self, amount: int) -> str:
        """
        Generate message string with given amount
        
        Args:
            amount: Dollar amount to include in message
            
        Returns:
            Formatted message string
        """
        return f"Mario owes {self.firstname} {amount} dollars"

    def hash_message(self, message: str) -> int:
        """
        Calculate SSHA-1 hash (first 10 + last 24 bits of SHA-1)
        
        Args:
            message: Message to hash
            
        Returns:
            34-bit hash value as integer
            
        Raises:
            CollisionFinderError: If hashing fails
        """
        try:
            # Calculate full SHA-1 hash
            sha1_hash = hashlib.sha1(message.encode()).hexdigest()
            
            # Convert hex to binary string (160 bits)
            binary = bin(int(sha1_hash, 16))[2:].zfill(160)
            
            # Extract first 10 and last 24 bits
            selected_bits = binary[:10] + binary[-24:]
            
            # Convert to integer
            return int(selected_bits, 2)
            
        except Exception as e:
            raise CollisionFinderError(f"Hashing failed: {str(e)}")

def find_collision(hasher: SSHAHasher, max_trials: int = 1000000) -> Tuple[int, int, int, int]:
    """
    Find two different numbers that produce the same SSHA-1 hash
    
    Args:
        hasher: SSHAHasher instance
        max_trials: Maximum number of attempts
        
    Returns:
        Tuple of (x, x_prime, hash_value, trials)
        
    Raises:
        CollisionFinderError: If collision not found within max trials
    """
    seen_hashes = {}
    trials = 0
    
    try:
        while trials < max_trials:
            trials += 1
            
            # Generate random amount (reasonable range for dollars)
            x = random.randint(1, 1000000)
            
            # Generate and hash message
            message = hasher.generate_message(x)
            hash_value = hasher.hash_message(message)
            
            # Check if we've seen this hash before
            if hash_value in seen_hashes:
                x_prime = seen_hashes[hash_value]
                if x != x_prime:
                    return x, x_prime, hash_value, trials
            else:
                seen_hashes[hash_value] = x
                
        raise CollisionFinderError(f"No collision found after {max_trials} trials")
        
    except Exception as e:
        if not isinstance(e, CollisionFinderError):
            raise CollisionFinderError(f"Collision finding failed: {str(e)}")
        raise

def main():
    """Main function to run the collision finder"""
    print("SSHA-1 Hash Collision Finder")
    print("-" * 30)
    
    try:
        # Get user's first name
        firstname = input("Enter your first name: ").strip()
        
        # Create hasher
        hasher = SSHAHasher(firstname)
        
        print("\nSearching for collision... This may take a while...")
        
        # Find collision
        x, x_prime, hash_value, trials = find_collision(hasher)
        
        # Generate messages
        message1 = hasher.generate_message(x)
        message2 = hasher.generate_message(x_prime)
        
        # Display results
        print("\nCollision found!")
        print(f"\nMessage 1: {message1}")
        print(f"Message 2: {message2}")
        print(f"Hash value: {hash_value:034b}")  # Display as 34-bit binary
        print(f"Number of trials: {trials:,}")
        
    except CollisionFinderError as e:
        print(f"\nError: {e}")
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
    except Exception as e:
        print(f"\nUnexpected error: {e}")

if __name__ == "__main__":
    main()

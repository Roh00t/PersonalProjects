"""
CSCI361 ASSIGNMENT 2 TASK 1
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

# Task One. Least Common Multiple (2 marks)
## Overview
This Python program calculates the Least Common Multiple (LCM) of two integers provided by the user. The LCM is computed using the formula:
This approach leverages the built-in math.gcd function for efficiency.

## Features
1. Computes the LCM of two integers.
2. Uses the efficient mathematical relationship between LCM and GCD.
3. Validates user input for better error handling.

## Prerequisites
Python 3.x
math library (standard in Python)

##How to Use

1. Ensure Python is installed on your system.
2. Save the script to a .py file, e.g., lcm_calculator.py.
3. Run the program from a terminal or command prompt:
python main.py
4. Enter two integers when prompted.
5. The program will output the LCM of the two integers.


## Example usage:
a = int(input("Enter the first number (a): "))
b = int(input("Enter the second number (b): "))
print(f"The LCM of {a} and {b} is {LCM(a, b)}.")

## Example Output
Enter the first number (a): 15
Enter the second number (b): 20
The LCM of 15 and 20 is 60.

# License
This program is provided as-is with no warranty. Feel free to use and modify the code for personal or educational purposes.

# Author
Rohit Panda
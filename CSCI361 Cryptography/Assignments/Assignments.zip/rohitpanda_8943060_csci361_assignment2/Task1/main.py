"""
CSCI361 ASSIGNMENT 2 TASK 1
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
import math

class LCMError(Exception):
    """Custom exception class for LCM calculation errors"""
    pass

def validate_input(num: int, name: str) -> None:
    """
    Validate input number for LCM calculation.
    
    Args:
        num: Number to validate
        name: Variable name for error messages
        
    Raises:
        LCMError: If input is invalid
    """
    # Check if number is too large to process safely
    if abs(num) > 10**12:
        raise LCMError(f"{name} is too large. Please use numbers smaller than 10^12")
    
    # Check for zero
    if num == 0:
        raise LCMError(f"{name} cannot be zero")
        
    # Check for non-integer values (shouldn't happen with int() conversion, but good practice)
    if not isinstance(num, int):
        raise LCMError(f"{name} must be an integer")

def LCM(a: int, b: int) -> int:
    """
    Calculate the Least Common Multiple (LCM) of two numbers.
    
    Args:
        a: First number
        b: Second number
        
    Returns:
        The LCM of a and b
        
    Raises:
        LCMError: If calculation fails or inputs are invalid
    """
    try:
        # Validate inputs
        validate_input(a, "First number")
        validate_input(b, "Second number")
        
        # Calculate LCM using the formula: |a * b| / gcd(a, b)
        try:
            result = abs(a * b) // math.gcd(a, b)
            
            # Check if result is too large
            if result > 10**12:
                raise LCMError("Result is too large to display")
                
            return result
            
        except OverflowError:
            raise LCMError("Numbers too large to calculate LCM")
            
    except TypeError as e:
        raise LCMError("Invalid input type. Please enter integers only")

def get_input(prompt: str) -> int:
    """
    Get and validate user input.
    
    Args:
        prompt: Input prompt message
        
    Returns:
        Validated integer input
        
    Raises:
        ValueError: If input is invalid
    """
    value = input(prompt).strip()
    
    # Check for empty input
    if not value:
        raise ValueError("Input cannot be empty")
        
    # Check for decimal points
    if '.' in value:
        raise ValueError("Please enter whole numbers only")
        
    # Try to convert to integer
    try:
        return int(value)
    except ValueError:
        raise ValueError("Please enter a valid integer")

def main():
    """Main function to calculate LCM with error handling"""
    print("LCM Calculator")
    print("-" * 20)
    
    try:
        # Get first number
        a = get_input("Enter the first number (a): ")
        
        # Get second number
        b = get_input("Enter the second number (b): ")
        
        # Calculate and display result
        result = LCM(a, b)
        print(f"\nThe LCM of {a} and {b} is {result:,}.")
        
    except ValueError as e:
        print(f"Input Error: {e}")
    except LCMError as e:
        print(f"Calculation Error: {e}")
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()

"""
CSCI361 ASSIGNMENT 2 TASK 3
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

class KnapsackError(Exception):
    
    """Custom exception class for Knapsack encryption-specific errors"""

    pass

def validate_superincreasing(sequence: list) -> bool:

    """
    Validate if a sequence is super-increasing (each element is greater than sum of all previous elements).
    
    Args:
        sequence (list): List of integers to validate
        
    Returns:
        bool: True if sequence is super-increasing, False otherwise
    """

    current_sum = 0
    for num in sequence:
        if num <= current_sum:
            return False
        current_sum += num
    return True

def gcd(a: int, b: int) -> int:

    """
    Calculate Greatest Common Divisor using Euclidean algorithm.
    
    Args:
        a (int): First number
        b (int): Second number
        
    Returns:
        int: GCD of a and b
    """

    while b:
        a, b = b, a % b
    return a

def mod_inverse(a: int, m: int) -> int:

    """
    Calculate modular multiplicative inverse.
    
    Args:
        a (int): Number to find inverse for
        m (int): Modulus
        
    Returns:
        int: Modular multiplicative inverse
        
    Raises:
        KnapsackError: If inverse doesn't exist
    """

    def extended_gcd(a: int, b: int) -> tuple:
        if a == 0:
            return b, 0, 1
        gcd, x1, y1 = extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y

    gcd, x, _ = extended_gcd(a, m)
    if gcd != 1:
        raise KnapsackError("Modular inverse does not exist")
    return (x % m + m) % m

class TrapdoorKnapsack:
    def __init__(self):

        """Initialize the Trapdoor Knapsack encryption system"""

        self.private_key = []
        self.public_key = []
        self.modulus = 0
        self.multiplier = 0
        
    def validate_inputs(self, size: int) -> None:

        """
        Validate the knapsack size input.
        
        Args:
            size (int): Size of the knapsack
            
        Raises:
            KnapsackError: If size is invalid
        """

        if not isinstance(size, int):
            raise KnapsackError("Size must be an integer")
        if size <= 0:
            raise KnapsackError("Size must be positive")
        if size > 100:  # Practical limit to prevent memory issues
            raise KnapsackError("Size too large (maximum: 100)")

    def setup(self) -> None:

        """
        Set up the encryption system by getting user inputs and generating keys.
        
        Raises:
            KnapsackError: If inputs are invalid
        """

        try:
            # Get knapsack size

            size = int(input("Enter the size of super-increasing knapsack: "))
            self.validate_inputs(size)
            
            # Get private key elements

            print(f"\nEnter {size} values for private key (super-increasing sequence):")
            self.private_key = []
            for i in range(size):
                value = int(input(f"Enter a[{i}]: "))
                if value <= 0:
                    raise KnapsackError(f"Element a[{i}] must be positive")
                self.private_key.append(value)
                
            # Validate super-increasing property

            if not validate_superincreasing(self.private_key):
                raise KnapsackError("Sequence is not super-increasing")
                
            # Get modulus and multiplier

            sum_private = sum(self.private_key)
            self.modulus = int(input("\nEnter modulus (must be greater than sum of private key): "))
            if self.modulus <= sum_private:
                raise KnapsackError(f"Modulus must be greater than {sum_private}")
                
            self.multiplier = int(input("Enter multiplier (must be coprime with modulus): "))
            if gcd(self.multiplier, self.modulus) != 1:
                raise KnapsackError("Multiplier must be coprime with modulus")
                
            # Generate public key

            self.public_key = [(x * self.multiplier) % self.modulus for x in self.private_key]
            
            # Display public key

            print("\nPublic Key generated:")
            print(self.public_key)
            
        except ValueError as e:
            raise KnapsackError("Invalid input: Please enter valid integers")

    def encrypt(self, message: str) -> int:

        """
        Encrypt a binary message using the public key.
        
        Args:
            message (str): Binary message to encrypt
            
        Returns:
            int: Encrypted ciphertext
            
        Raises:
            KnapsackError: If message is invalid
        """

        if not all(bit in '01' for bit in message):
            raise KnapsackError("Message must be a binary string")
        if len(message) != len(self.public_key):
            raise KnapsackError(f"Message must be {len(self.public_key)} bits long")
            
        ciphertext = sum(int(bit) * key for bit, key in zip(message, self.public_key))
        return ciphertext

    def decrypt(self, ciphertext: int) -> str:

        """
        Decrypt a ciphertext using the private key.
        
        Args:
            ciphertext (int): Ciphertext to decrypt
            
        Returns:
            str: Decrypted binary message
            
        Raises:
            KnapsackError: If decryption fails
        """

        try:
            # Calculate modular inverse of multiplier


            inv_multiplier = mod_inverse(self.multiplier, self.modulus)
            
            # Transform ciphertext

            modified_cipher = (ciphertext * inv_multiplier) % self.modulus
            
            # Solve subset sum problem

            message = ['0'] * len(self.private_key)
            remaining = modified_cipher
            
            # Work backwards through private key


            for i in range(len(self.private_key) - 1, -1, -1):
                if remaining >= self.private_key[i]:
                    message[i] = '1'
                    remaining -= self.private_key[i]
                    
            if remaining != 0:
                raise KnapsackError("Decryption failed: Invalid ciphertext")
                
            return ''.join(message)
            
        except Exception as e:
            raise KnapsackError(f"Decryption failed: {str(e)}")

def main():

    """Main function to run the encryption system"""

    try:
        # Initialize system
        knapsack = TrapdoorKnapsack()
        
        # Setup keys

        knapsack.setup()
        
        # Get message and encrypt

        message = input("\nEnter binary message: ")
        ciphertext = knapsack.encrypt(message)
        print(f"Encrypted ciphertext: {ciphertext}")
        
        # Get ciphertext and decrypt
        decrypt_cipher = int(input("\nEnter ciphertext to decrypt: "))
        decrypted = knapsack.decrypt(decrypt_cipher)
        print(f"Decrypted message: {decrypted}")
        
    except KnapsackError as e:
        print(f"Error: {e}")
    except KeyboardInterrupt:
        print("\nOperation cancelled")
    except Exception as e:
        print(f"Unexpected error occurred: {e}")

if __name__ == "__main__":
    main()

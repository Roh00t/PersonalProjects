"""
CSCI361 ASSIGNMENT 2 TASK 3
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

# Task Three. Implementation of Trapdoor Knapsack En- cryption Scheme (2 marks)
This program implements a Trapdoor Knapsack encryption scheme, a type of public-key cryptography system based on the subset sum problem and super-increasing sequences.

## Features
- Generation of public and private keys
- Message encryption using public key
- Ciphertext decryption using private key
- Comprehensive input validation
- Error handling for all operations

## Mathematical Background
The system uses:
1. Super-increasing sequences for private key
2. Modular arithmetic for key transformation
3. Subset sum problem for encryption/decryption

## Requirements
- Python 3.x

## Usage
1. Run the program:
```bash
python knapsack.py
```

2. Follow the prompts to:
   - Enter size of the knapsack
   - Input private key values (must form a super-increasing sequence)
   - Specify modulus and multiplier
   - Enter binary message for encryption
   - Enter ciphertext for decryption

## Input Requirements
1. Knapsack Size:
   - Must be positive integer
   - Maximum size: 100

2. Private Key:
   - Must form a super-increasing sequence
   - All values must be positive integers

3. Modulus:
   - Must be greater than sum of private key elements

4. Multiplier:
   - Must be coprime with modulus

5. Message:
   - Must be binary string
   - Length must match knapsack size

## Error Handling
The program handles:
- Invalid input types
- Non-super-increasing sequences
- Invalid modulus/multiplier combinations
- Incorrect message formats
- Decryption failures
- System interruptions

## Security Note
This implementation is for educational purposes. The Merkle-Hellman knapsack cryptosystem has been broken and should not be used for actual security purposes.

## Example Usage
```
Enter the size of super-increasing knapsack: 4
Enter 4 values for private key (super-increasing sequence):
Enter a[0]: 2
Enter a[1]: 5
Enter a[2]: 10
Enter a[3]: 20

Enter modulus: 40
Enter multiplier: 7

Public Key generated:
[14, 35, 30, 20]

Enter binary message: 1010
Encrypted ciphertext: 34

Enter ciphertext to decrypt: 34
Decrypted message: 1010
```
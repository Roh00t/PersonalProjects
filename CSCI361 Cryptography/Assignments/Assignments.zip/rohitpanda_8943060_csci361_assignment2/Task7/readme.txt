"""
CSCI361 ASSIGNMENT 2 TASK 7
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

# Task Seven: Analysis of RSA algorithm (2 marks)
This implementation analyzes the security implications of using RSA encryption with the same modulus and different encryption exponents. 
It demonstrates how to recover plaintext without knowing the private key when a message is encrypted twice with different exponents.

## Mathematical Background
The attack works because:
1. When m is encrypted with e1: c1 ≡ m^e1 (mod N)
2. When m is encrypted with e2: c2 ≡ m^e2 (mod N)
3. If e1 and e2 are coprime, we can find s and t such that:
   s*e1 + t*e2 = 1 (using extended GCD)
4. Then: m ≡ c1^s * c2^t (mod N)

## Features
- Plaintext recovery from double encryption
- Security analysis
- Extended Euclidean Algorithm implementation
- Parameter validation
- Comprehensive error handling

## Class: RSAAnalyzer
### Methods
- `__init__(N, e1, e2)`: Initialize with RSA parameters
- `recover_plaintext(c1, c2)`: Recover plaintext from two ciphertexts
- `analyze_security()`: Provide security analysis
- `_extended_gcd(a, b)`: Implementation of extended Euclidean algorithm

## Usage
```python
# Initialize RSAAnalyzer with modulus and exponents
N = 3233  # Example modulus (product of two primes)
e1 = 17   # First encryption exponent
e2 = 23   # Second encryption exponent

# Create an instance of RSAAnalyzer
analyzer = RSAAnalyzer(N, e1, e2)

# Encrypt a message with both exponents
original_message = 123
c1 = pow(original_message, e1, N)
c2 = pow(original_message, e2, N)

# Recover the plaintext
recovered_message = analyzer.recover_plaintext(c1, c2)
print(f"Recovered message: {recovered_message}")

# Perform security analysis
analysis = analyzer.analyze_security()
for key, value in analysis.items():
    print(f"{key}: {value}")
```

## Example Output
```bash
RSA Analysis Results:
Original message: 123
Recovered message: 123
Recovery successful: True

Security Analysis:
vulnerable_to_plaintext_recovery: True
reason: Multiple encryptions with coprime exponents
attack_method: Common modulus attack using extended GCD
mitigation: Never encrypt the same message with different exponents using the same modulus
time_analyzed: 2025-01-31T23:52:27.665367
```
### Key points:

- The RSAAnalyzer class is able to recover the plaintext by exploiting the fact that the same message is encrypted 
with two different exponents (e1 and e2) using the same modulus (N).

- This is a known vulnerability, referred to as a "common modulus attack", which can be used 
when the encryption exponents are coprime.

- The security analysis correctly identifies that this setup is vulnerable to plaintext recovery, 
explains the attack method, and provides the mitigation recommendation of never encrypting 
the same message with different exponents using the same modulus

## Notes
- Ensure that the encryption exponents are coprime for the attack to work.
- This implementation is for educational purposes and demonstrates a known vulnerability in RSA encryption when misused.
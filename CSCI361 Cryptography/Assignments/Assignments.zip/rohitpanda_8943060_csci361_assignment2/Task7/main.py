"""
CSCI361 ASSIGNMENT 2 TASK 7
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

from typing import Tuple
import math
from datetime import datetime
import sys

class RSAAnalyzer:
    def __init__(self, N: int, e1: int, e2: int):
        """Initialize with public modulus and two encryption exponents"""
        self.N = N
        self.e1 = e1
        self.e2 = e2
        self._validate_parameters()
    
    def _validate_parameters(self):
        """Validate RSA parameters"""
        if self.N < 3:
            raise ValueError("N must be greater than 2")
        if self.e1 == self.e2:
            raise ValueError("Encryption exponents must be different")
        if math.gcd(self.e1, self.e2) != 1:
            raise ValueError("Encryption exponents must be coprime")
            
    def _extended_gcd(self, a: int, b: int) -> Tuple[int, int, int]:
        """Extended Euclidean Algorithm"""
        if a == 0:
            return b, 0, 1
        gcd, x1, y1 = self._extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y
    
    def recover_plaintext(self, c1: int, c2: int) -> int:
        """
        Attempt to recover plaintext from two ciphertexts
        Uses the fact that m^e1 ≡ c1 (mod N) and m^e2 ≡ c2 (mod N)
        """
        try:
            # Find coefficients using extended GCD: s*e1 + t*e2 = gcd(e1,e2)
            gcd, s, t = self._extended_gcd(self.e1, self.e2)
            
            if gcd != 1:
                raise ValueError("Encryption exponents must be coprime")
            
            # If s < 0, adjust the formula
            if s < 0:
                s = -s
                c1 = pow(c1, -1, self.N)
            if t < 0:
                t = -t
                c2 = pow(c2, -1, self.N)
            
            # Compute plaintext: m = c1^s * c2^t mod N
            m = (pow(c1, s, self.N) * pow(c2, t, self.N)) % self.N
            return m
            
        except Exception as e:
            raise RuntimeError(f"Failed to recover plaintext: {str(e)}")
    
    def analyze_security(self) -> dict:
        """Analyze the security implications of the setup"""
        return {
            "vulnerable_to_plaintext_recovery": True,
            "reason": "Multiple encryptions with coprime exponents",
            "attack_method": "Common modulus attack using extended GCD",
            "mitigation": "Never encrypt the same message with different exponents using the same modulus",
            "time_analyzed": datetime.now().isoformat()
        }

def main():
    try:
        # Example parameters
        N = 3233  # 61 * 53
        e1 = 17
        e2 = 23
        
        # Create message and encrypt it
        original_message = 123
        c1 = pow(original_message, e1, N)
        c2 = pow(original_message, e2, N)
        
        # Initialize analyzer
        analyzer = RSAAnalyzer(N, e1, e2)
        
        # Attempt to recover plaintext
        recovered_message = analyzer.recover_plaintext(c1, c2)
        
        print("\nRSA Analysis Results:")
        print(f"Original message: {original_message}")
        print(f"Recovered message: {recovered_message}")
        print(f"Recovery successful: {original_message == recovered_message}")
        
        # Get security analysis
        analysis = analyzer.analyze_security()
        print("\nSecurity Analysis:")
        for key, value in analysis.items():
            print(f"{key}: {value}")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

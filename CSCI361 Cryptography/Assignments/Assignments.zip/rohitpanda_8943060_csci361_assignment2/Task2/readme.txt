"""
CSCI361 ASSIGNMENT 2 TASK 2
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

# Task Two. Implementation of Extended GCD Algorithm (2 marks)
This program implements the Extended Euclidean Algorithm to find the Greatest Common Divisor (GCD) of two numbers and their Bézout's identity coefficients.

## Description
Given two numbers a and b, the program finds:
1. Their GCD (Greatest Common Divisor)
2. The coefficients α and β such that: αa + βb = gcd(a, b)

The program shows each step of the algorithm, making it useful for educational purposes and verification of results.

## Features
- Interactive input for two numbers
- Step-by-step display of the algorithm's execution
- Clear presentation of intermediate values
- Final summary showing GCD and the coefficients

## Usage
1. Run the program
2. Enter the first number (a) when prompted
3. Enter the second number (b) when prompted
4. The program will display:
   - Each step of the algorithm
   - The final GCD
   - The coefficients that satisfy Bézout's identity

## Example Output
```bash
$gcd
Enter a = 39
Enter b = 11
We are to find gcd(39, 11) using the Extended Eucledian algorithm.
The contents of the variables are as follows:
n1 n2 r  q  a1 b1 a2 b2
39 11 6  3  1  0  0  1
11 6  5  1  0  1  1  -3
6  5  1  1  1  -3 -1 4
5  1  0  5  -1 4  2  -7

Summary:
gcd(39, 11) = 1
39 * 2 + 11 * -7 = 1
```

## Error Handling
The program includes error handling for:
- Invalid input (non-integer values)
- Zero as the second number
- General input errors

## Requirements
- Python 3.x

## Implementation Details
The algorithm uses an iterative approach to compute the GCD and coefficients simultaneously. 
It maintains two pairs of coefficients throughout the computation and updates them based on the quotient at each step.
"""
CSCI361 ASSIGNMENT 2 TASK 2
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

class GCDError(Exception):
    """Custom exception class for GCD-specific errors"""
    pass

def validate_inputs(a: int, b: int) -> None:
    """
    Validate the input parameters for the Extended GCD algorithm.
    
    Args:
        a (int): First number
        b (int): Second number
        
    Raises:
        GCDError: If inputs are invalid
        ValueError: If inputs cannot be converted to integers
    """
    # Check if inputs are actually integers
    if not (isinstance(a, int) and isinstance(b, int)):
        raise ValueError("Inputs must be integers")
    
    # Check if both inputs are zero
    if a == 0 and b == 0:
        raise GCDError("Both numbers cannot be zero")
        
    # Handle negative numbers by converting to positive
    if a < 0 or b < 0:
        raise GCDError("Please enter positive integers only")
    
    # Check for very large numbers that might cause performance issues
    if abs(a) > 10**9 or abs(b) > 10**9:
        raise GCDError("Numbers are too large (limit: 1e9)")

def extended_gcd(a: int, b: int) -> None:
    """
    Implementation of Extended Euclidean Algorithm to find GCD and coefficients.
    Prints each step of the algorithm and final results.
    
    Args:
        a (int): First number
        b (int): Second number
        
    Raises:
        GCDError: If inputs are invalid
        ValueError: If inputs cannot be converted to integers
    """
    try:
        # Validate inputs
        validate_inputs(a, b)
        
        # Ensure b is not zero before proceeding
        if b == 0:
            raise GCDError("Second number cannot be zero")
            
        # Initialize variables for the algorithm
        n1, n2 = a, b
        a1, b1 = 1, 0  # Coefficients for n1
        a2, b2 = 0, 1  # Coefficients for n2
        
        # Print header
        print("\nWe are to find gcd({}, {}) using the Extended Eucledian algorithm.".format(a, b))
        print("The contents of the variables are as follows:")
        print("n1 n2 r  q  a1 b1 a2 b2")
        
        while True:
            try:
                # Calculate quotient and remainder
                q = n1 // n2
                r = n1 % n2
                
                # Print current state
                print(f"{n1:<2} {n2:<2} {r:<2} {q:<2}", end=" ")
                print(f"{a1:<2} {b1:<2} {a2:<2} {b2:<2}")
                
                if r == 0:
                    break
                    
                # Update values for next iteration
                n1, n2 = n2, r
                
                # Update coefficients
                a1, a2 = a2, a1 - q * a2
                b1, b2 = b2, b1 - q * b2
                
                # Check for potential integer overflow
                if any(abs(x) > 10**9 for x in [a1, a2, b1, b2]):
                    raise GCDError("Coefficient overflow occurred")
                    
            except ZeroDivisionError:
                raise GCDError("Unexpected division by zero occurred")
                
        # Verify the result
        if a * a2 + b * b2 != n2:
            raise GCDError("Algorithm result verification failed")
            
        # Print summary
        print("\nSummary:")
        print(f"gcd({a}, {b}) = {n2}")
        print(f"{a} * {a2} + {b} * {b2} = {n2}")
        
    except (OverflowError, MemoryError):
        raise GCDError("Numbers too large to process")

def parse_input(prompt: str) -> int:
    """
    Parse and validate user input.
    
    Args:
        prompt (str): Input prompt message
        
    Returns:
        int: Validated integer input
        
    Raises:
        ValueError: If input cannot be converted to integer
    """
    try:
        value = input(prompt)
        # Check for empty input
        if not value.strip():
            raise ValueError("Input cannot be empty")
        # Check for decimal points
        if '.' in value:
            raise ValueError("Please enter whole numbers only")
        return int(value)
    except ValueError as e:
        if "invalid literal for int()" in str(e):
            raise ValueError("Please enter a valid integer")
        raise

def main():
    """
    Main function to get user input and run the algorithm.
    Handles all potential errors and provides user-friendly error messages.
    """
    print("$gcd")
    try:
        # Get and validate inputs
        try:
            a = parse_input("Enter a = ")
            b = parse_input("Enter b = ")
        except ValueError as e:
            print(f"Input Error: {e}")
            return
            
        # Run the algorithm
        extended_gcd(a, b)
        
    except GCDError as e:
        print(f"GCD Error: {e}")
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
    except Exception as e:
        print(f"Unexpected error occurred: {e}")
        print("Please try again with different inputs")

if __name__ == "__main__":
    main()

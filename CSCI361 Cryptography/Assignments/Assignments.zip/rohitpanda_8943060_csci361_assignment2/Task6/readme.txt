"""
CSCI361 ASSIGNMENT 2 TASK 6
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
# Task Six. Diffie-Hellman Key Exchange and Man-in-the middle attack implementation (3 marks)

This Python implementation provides a Diffie-Hellman key exchange algorithm and demonstrates how to prevent man-in-the-middle (MITM) attacks.

## Output Example:
1. OUTPUT EXAMPLE:
```bash
Prime: 2638539111430270060464953972419105603940964656984007115630628668514056599468945712917403416592696438010988063230753848648306523968831979939863231452660809
Generator: 266287755563725345147394535574026908055918189741271569211076969432977439124686345225784435566221305853766642566701718618552937417949048922354880987131794
Keys match: True
MITM Attack Demonstration:
Eve-Alice key: 1039878726244978853928434103423768838382761307585424715088134236121166639073298889633676830905881737025261331419690680007786930032235696755714769159322647
Secure DH with Authentication:
Alice verifies Bob's key: True
Bob verifies Alice's key: True
```

The output demonstrates the implementation of the Diffie-Hellman key exchange algorithm and the man-in-the-middle attack, 
as well as the secure version that prevents the attack.


## Features
- Diffie-Hellman key exchange
- MITM attack demonstration
- Secure version with authentication to prevent MITM

## Usage

1. Generate Diffie-Hellman parameters:
   ```python
   dh = DiffieHellman()
   print(f"Prime: {dh.p}")
   print(f"Generator: {dh.g}")
   ```

2. Perform key exchange:
   ```python
   alice_private = dh.generate_private_key()
   alice_public = dh.generate_public_key(alice_private)
   bob_private = dh.generate_private_key()
   bob_public = dh.generate_public_key(bob_private)

   alice_secret = dh.compute_shared_secret(alice_private, bob_public)
   bob_secret = dh.compute_shared_secret(bob_private, alice_public)
   print(f"Keys match: {alice_secret == bob_secret}")
   ```

3. Demonstrate MITM attack:
   ```python
   print("MITM Attack Demonstration:")
   eve_private = dh.generate_private_key()
   eve_public = dh.generate_public_key(eve_private)
   alice_eve_secret = dh.compute_shared_secret(alice_private, eve_public)
   eve_alice_secret = dh.compute_shared_secret(eve_private, alice_public)
   print(f"Eve-Alice key: {eve_alice_secret}")
   ```

4. Implement secure version with authentication:
   ```python
   print("Secure DH with Authentication:")
   alice_secure = SecureDiffieHellman(dh.p, dh.g)
   bob_secure = SecureDiffieHellman(dh.p, dh.g)
   alice_signature = alice_secure.sign_public_key(alice_public)
   bob_signature = bob_secure.sign_public_key(bob_public)
   print("Alice verifies Bob's key:", alice_secure.verify_signature(bob_public, bob_signature))
   print("Bob verifies Alice's key:", bob_secure.verify_signature(alice_public, alice_signature))
   ```

The secure version uses HMAC-based authentication with a pre-shared secret to prevent MITM attacks.

## Security Considerations
- Uses cryptographically secure random number generation
- Implements Miller-Rabin primality testing
- Validates all parameters
- Prevents MITM attacks in secure version
- Uses SHA-256 for key derivation and HMAC for signatures
"""
CSCI361 ASSIGNMENT 2 TASK 6
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
import random
import hashlib
import hmac

class DiffieHellman:
    def __init__(self, p=None, g=None):
        self.p = p or self._get_prime(512)
        self.g = g or self._find_generator()

    def _get_prime(self, bits=512):
        while True:
            p = random.getrandbits(bits) | 1
            if self._is_prime(p):
                return p

    def _is_prime(self, n, k=5):
        if n < 2: return False
        for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]:
            if n % p == 0: return n == p
        s, d = 0, n - 1
        while d % 2 == 0:
            s += 1
            d //= 2
        for _ in range(k):
            a = random.randrange(2, n - 1)
            x = pow(a, d, n)
            if x == 1 or x == n - 1: continue
            for _ in range(s - 1):
                x = pow(x, 2, n)
                if x == n - 1: break
            else: return False
        return True

    def _find_generator(self):
        while True:
            g = random.randrange(2, self.p - 1)
            if pow(g, (self.p - 1) // 2, self.p) != 1:
                return g

    def generate_private_key(self):
        return random.randrange(2, self.p - 1)

    def generate_public_key(self, private_key):
        return pow(self.g, private_key, self.p)

    def compute_shared_secret(self, private_key, other_public_key):
        if other_public_key <= 1 or other_public_key >= self.p:
            raise ValueError("Invalid public key")
        return pow(other_public_key, private_key, self.p)

class SecureDiffieHellman(DiffieHellman):
    def __init__(self, p=None, g=None, pre_shared_secret="secret"):
        super().__init__(p, g)
        self.pre_shared_secret = pre_shared_secret.encode()

    def sign_public_key(self, public_key):
        message = str(public_key).encode()
        return hmac.new(self.pre_shared_secret, message, hashlib.sha256).digest()

    def verify_signature(self, public_key, signature):
        message = str(public_key).encode()
        expected = hmac.new(self.pre_shared_secret, message, hashlib.sha256).digest()
        return signature == expected

def main():
    dh = DiffieHellman()
    print(f"Prime: {dh.p}")
    print(f"Generator: {dh.g}")

    alice_private = dh.generate_private_key()
    alice_public = dh.generate_public_key(alice_private)
    bob_private = dh.generate_private_key()
    bob_public = dh.generate_public_key(bob_private)

    alice_secret = dh.compute_shared_secret(alice_private, bob_public)
    bob_secret = dh.compute_shared_secret(bob_private, alice_public)
    print(f"Keys match: {alice_secret == bob_secret}")

    print("MITM Attack Demonstration:")
    eve_private = dh.generate_private_key()
    eve_public = dh.generate_public_key(eve_private)
    alice_eve_secret = dh.compute_shared_secret(alice_private, eve_public)
    eve_alice_secret = dh.compute_shared_secret(eve_private, alice_public)
    print(f"Eve-Alice key: {eve_alice_secret}")

    print("Secure DH with Authentication:")
    alice_secure = SecureDiffieHellman(dh.p, dh.g)
    bob_secure = SecureDiffieHellman(dh.p, dh.g)
    alice_signature = alice_secure.sign_public_key(alice_public)
    bob_signature = bob_secure.sign_public_key(bob_public)
    print("Alice verifies Bob's key:", alice_secure.verify_signature(bob_public, bob_signature))
    print("Bob verifies Alice's key:", bob_secure.verify_signature(alice_public, alice_signature))

if __name__ == "__main__":
    main()
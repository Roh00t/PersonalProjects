# Kamasutra Cipher

This project implements the **Flipped Kamasutra Cipher** as specified in the assignment. The cipher is a substitution cipher where each letter of the alphabet is paired with another, forming a one-to-one mapping for encryption and decryption.

## Features
- **Random Key Generation**: Generate a random key pair and save it to a keyfile.
- **Encryption**: Encrypt a plaintext file using a keyfile.
- **Decryption**: Decrypt a ciphertext file using a keyfile.
- **Error Handling**: Handles invalid input files and arguments gracefully.
- **Preserves Non-Alphabet Characters**: Non-alphabetic characters are left unchanged during encryption and decryption.

---

## Command Syntax
The program can be executed with the following commands:
0. **Remove unwanted files**
```bash
rm ciphertext.txt keyfile.txt decrypted.txt 
```

1. **Generate Keyfile**:
   ```bash
   python Kamasutra.py -k <keyfile.txt>
```

2. **Encrypt A File**
```bash
python Kamasutra.py -e <keyfile.txt> <plaintext.txt> <ciphertext.txt>
```

3. **Decrypt A File**
```bash
python Kamasutra.py -d <keyfile.txt> <ciphertext.txt> <plaintext.txt>
```

## Usage Example:
Use the command below to run the whole program:
```bash
echo "GENERATING KEYFILE" && python Kamasutra.py -k keyfile.txt && ls && echo "CONTENTS of Plaintext File" && cat plaintext.txt && echo "ENCRYPTING a Plaintext File" && python Kamasutra.py -e keyfile.txt plaintext.txt ciphertext.txt && ls && echo "CONTENTS of ciphertext File"&& cat Ciphertext.txt && echo "DECRYPTING a Ciphertext File" && python Kamasutra.py -d keyfile.txt ciphertext.txt decrypted.txt && ls && echo "CONTENTS of Decrypted File" && cat decrypted.txt && echo "Verify Correctness, Compare the decrypted text with the original plaintext:" && diff plaintext.txt decrypted.txt
```
OUTPUT::
GENERATING KEYFILE
Keyfile generated and saved to keyfile.txt
Kamasutra.py	keyfile.txt	plaintext.txt	readme.txt
CONTENTS of Plaintext File
abab bcbc cdcd effe
ENCRYPTING a Plaintext File
Encryption successful. Output saved to ciphertext.txt
Kamasutra.py	ciphertext.txt	keyfile.txt	plaintext.txt	readme.txt
CONTENTS of ciphertext File
dldl lblb bsbs fxxf
DECRYPTING a Ciphertext File
Decryption successful. Output saved to decrypted.txt
Kamasutra.py	decrypted.txt	plaintext.txt
ciphertext.txt	keyfile.txt	readme.txt
CONTENTS of Decrypted File
abab bcbc cdcd effe
Verify Correctness, Compare the decrypted text with the original plaintext:
<Blank Output>
<blank output means no difference found>



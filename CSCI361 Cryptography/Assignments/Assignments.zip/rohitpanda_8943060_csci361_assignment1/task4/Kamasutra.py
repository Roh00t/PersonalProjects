"""
CSCI361 ASSIGNMENT 1 TASK 3
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

import sys
import random
import string

def generate_keyfile(keyfile_path):

    """
    Generate a random Kamasutra cipher key and save it to a file.
    """

    alphabet = list(string.ascii_lowercase)
    shuffled = alphabet[:]
    random.shuffle(shuffled)

    # Create substitution pairs

    pairs = dict(zip(alphabet, shuffled))

    # Write keyfile

    with open(keyfile_path, "w") as f:
        for char, pair in pairs.items():
            f.write(f"{char}:{pair}\n")

    print(f"Keyfile generated and saved to {keyfile_path}.")


def encrypt_file(keyfile_path, plaintext_file, ciphertext_file):

    """
    Encrypts the plaintext file using the Kamasutra cipher keyfile and saves the result to a ciphertext file.
    """

    # Load the substitution key from the keyfile


    key = {}
    with open(keyfile_path, "r") as f:
        for line in f:
            char, pair = line.strip().split(":")
            key[char.upper()] = pair.upper()  # Handle uppercase letters

    # Read plaintext

    with open(plaintext_file, "r") as f:
        plaintext = f.read()

    # Perform substitution

    ciphertext = []
    for char in plaintext.upper():
        if char in key:
            ciphertext.append(key[char])  # Substitute using the key

        else:
            ciphertext.append(char)  # Keep non-alphabet characters unchanged


    # Write ciphertext to the output file


    with open(ciphertext_file, "w") as f:
        f.write("".join(ciphertext))

    print(f"Encryption successful. Output saved to {ciphertext_file}.")


def decrypt_file(keyfile_path, ciphertext_file, plaintext_file):
    """
    Decrypts the ciphertext file using the Kamasutra cipher keyfile and saves the result to a plaintext file.
    """


    # Load the substitution key from the keyfile and reverse it

    reverse_key = {}
    with open(keyfile_path, "r") as f:
        for line in f:
            char, pair = line.strip().split(":")
            reverse_key[pair.upper()] = char.upper()  # Reverse the mapping

    # Read ciphertext

    with open(ciphertext_file, "r") as f:
        ciphertext = f.read()

    # Perform reverse substitution

    plaintext = []
    for char in ciphertext.upper():
        if char in reverse_key:
            plaintext.append(reverse_key[char])  # Substitute using the reverse key
        else:
            plaintext.append(char)  # Keep non-alphabet characters unchanged

    # Write plaintext to the output file

    with open(plaintext_file, "w") as f:
        f.write("".join(plaintext))

    print(f"Decryption successful. Output saved to {plaintext_file}.")


def main():

    """
    Main function to handle command-line arguments.
    """

    if len(sys.argv) < 3:
        print("Usage:")
        print("  python3 Kamasutra.py -k <keyfile.txt>")
        print("  python3 Kamasutra.py -e <keyfile.txt> <plaintext.txt> <ciphertext.txt>")
        print("  python3 Kamasutra.py -d <keyfile.txt> <ciphertext.txt> <plaintext.txt>")
        sys.exit(1)

    option = sys.argv[1]

    if option == "-k" and len(sys.argv) == 3:
        # Generate keyfile
        keyfile_path = sys.argv[2]
        generate_keyfile(keyfile_path)

    elif option == "-e" and len(sys.argv) == 5:
        # Encrypt
        keyfile_path = sys.argv[2]
        plaintext_file = sys.argv[3]
        ciphertext_file = sys.argv[4]
        encrypt_file(keyfile_path, plaintext_file, ciphertext_file)

    elif option == "-d" and len(sys.argv) == 5:
        # Decrypt
        
        keyfile_path = sys.argv[2]
        ciphertext_file = sys.argv[3]
        plaintext_file = sys.argv[4]
        decrypt_file(keyfile_path, ciphertext_file, plaintext_file)

    else:
        print("Invalid usage. Please follow the usage instructions.")
        sys.exit(1)


if __name__ == "__main__":
    main()

# Substitution Cipher Program
## Description:
This program implements a substitution cipher based on a keyword. It can:
	1.	Encrypt a plaintext message from a file.
		Message: I LOVE WOLLONGONG
	2.	Decrypt a ciphertext message from a file.

## How It Works:
1.	The program constructs a substitution key using the provided keyword.
	• Duplicate letters in the keyword are removed.
	• The remaining letters of the alphabet (in reverse order) are appended to the keyword.
		Example: 
		Keyword = “STRAWBERRY” ➡ Key = “STRAWBEYZXVUQPONMLKJIHGFDC”
2.	Special characters and spaces are ignored during encryption and decryption. They are left unchanged in the output.

3.	Example:
		```bash
		(base) rohitpanda@Rohits-MBP task2 % ls
		plaintext.txt		readme.txt		substitution_cipher.py
		(base) rohitpanda@Rohits-MBP task2 % python substitution_cipher.py STRAWBERRY encrypt plaintext.txt ciphertext.txt
		Encryption successful. Output written to ciphertext.txt
		(base) rohitpanda@Rohits-MBP task2 % ls
		ciphertext.txt		plaintext.txt		readme.txt		substitution_cipher.py
		(base) rohitpanda@Rohits-MBP task2 % cat ciphertext.txt 
		Z UOHW, GOUUOPEOPE!!!
		(base) rohitpanda@Rohits-MBP task2 % python substitution_cipher.py STRAWBERRY decrypt ciphertext.txt decrypted.txt
		Decryption successful. Output written to decrypted.txt
		(base) rohitpanda@Rohits-MBP task2 % cat decrypted.txt 
		I LOVE, WOLLONGONG!!!
		```

## Features
	• Input and Output: Handles files for both plaintext and ciphertext.
	• Modes: encrypt or decrypt are supported.
	• Error Handling: Detects invalid files and arguments.
	• Case Insensitivity: All input is converted to uppercase.

## Requirements
Python 3.x installed on your system.

## Usage
Remove ciphertext.txt and decrypted.txt.

Run the program from the command line as follows:
```bash
python substitution_cipher.py <keyword> <mode> <input_file> <output_file>
```
Arguments
	• <keyword>: The keyword for generating the substitution cipher key.
	• <mode>: Either encrypt or decrypt.
	• <input_file>: The path to the input file (plaintext or ciphertext).
	• <output_file>: The path to the output file where the result will be saved.

## Example
To encrypt a message:
```bash
python substitution_cipher.py STRAWBERRY encrypt plaintext.txt ciphertext.txt
```
To decrypt a message:
```bash
python substitution_cipher.py STRAWBERRY decrypt ciphertext.txt decrypted.txt
```
To verify the decrytion is successful:
```bash
diff plaintext.txt decrypted.txt
```

## Files
	• plaintext.txt: Contains the plaintext message: I LOVE WOLLONGONG to encrypt.
	• ciphertext.txt: Contains the ciphertext message to decrypt.
	• decrypted.txt: Contains the decrypted plaintext.


## Error Handling
	•If the input file does not exist, an error message will be displayed.
	•Ensure all command-line arguments are provided, or the program will exit with an error.
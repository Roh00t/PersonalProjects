"""
CSCI361 ASSIGNMENT 1 TASK 2
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
import sys  # Used for command-line arguments
import string  # Used for string manipulation
from pathlib import Path  # Used for file input/output


# Function to generate a substitution key based on the keyword
def generate_key(keyword):

    """
    Generate the substitution cipher key based on the given keyword.
    - Removes duplicate characters from the keyword while maintaining order.
    - Appends the remaining letters of the alphabet in reverse order.

    Parameters:
    keyword (str): The keyword used to generate the substitution cipher key.

    Returns:
    str: The complete substitution cipher key.
    """

    keyword = keyword.upper()  # Ensure the keyword is in uppercase
    seen = set()  # Track seen characters to remove duplicates
    # Filter the keyword to include only unique characters in order
    keyword_unique = "".join(char for char in keyword if char not in seen and not seen.add(char))
    # Add remaining letters of the alphabet in reverse order
    full_key = keyword_unique + "".join(
        char for char in string.ascii_uppercase[::-1] if char not in seen
    )
    return full_key  # Return the complete substitution cipher key



# Function to encrypt or decrypt a message using the substitution cipher
def translate(message, key, mode="encrypt"):
    
    """
    Encrypt or decrypt a message using the substitution cipher.

    Parameters:
    message (str): The input text to be translated (plaintext or ciphertext).
    key (str): The substitution cipher key.
    mode (str): The mode of operation - "encrypt" or "decrypt".

    Returns:
    str: The translated message (ciphertext or plaintext).
    """

    alphabet = string.ascii_uppercase  # Standard uppercase alphabet
    # Create a translation table for encryption or decryption
    translation_table = str.maketrans(alphabet, key) if mode == "encrypt" else str.maketrans(key, alphabet)
    return message.upper().translate(translation_table)  # Apply translation and return the result



# Main function to handle the program logic
def main():

    """
    Main function for the substitution cipher program.
    - Handles command-line arguments for keyword, mode, input file, and output file.
    - Reads the input file and writes the result to the output file.
    - Performs encryption or decryption based on the specified mode.
    """
    
    # Check if the required command-line arguments are provided
    if len(sys.argv) < 5:
        print("Usage: python substitution_cipher.py <keyword> <mode> <input_file> <output_file>")
        print("Modes: encrypt or decrypt")  # Inform the user about valid modes
        sys.exit(1)  # Exit with an error code if arguments are insufficient

    # Extract arguments from the command line
    keyword = sys.argv[1]  # Keyword for generating the substitution key
    mode = sys.argv[2].lower()  # Mode of operation (convert to lowercase)
    input_file = Path(sys.argv[3])  # Path to the input file
    output_file = Path(sys.argv[4])  # Path to the output file

    # Validate the mode argument (it must be "encrypt" or "decrypt")
    if mode not in ["encrypt", "decrypt"]:
        print("Invalid mode. Use 'encrypt' or 'decrypt'.")
        sys.exit(1)  # Exit with an error code if the mode is invalid

    # Generate the substitution cipher key based on the keyword
    key = generate_key(keyword)

    try:
        # Read the content of the input file
        data = input_file.read_text()

        # Translate the content (encrypt or decrypt) based on the mode
        result = translate(data, key, mode)

        # Write the translated result to the output file
        output_file.write_text(result)

        # Inform the user that the operation was successful
        print(f"{mode.capitalize()}ion successful. Output written to {output_file}")

    except FileNotFoundError:
        # Handle the case where the input file does not exist
        print(f"Error: File '{input_file}' not found.")
    except Exception as e:
        # Handle any other unexpected errors
        print(f"An error occurred: {e}")



if __name__ == "__main__":
    main()

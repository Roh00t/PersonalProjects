# Assignment 1, Task 5: Symmetric Cryptosystem Analysis
## Description
This Python script calculates the GCD (Greatest Common Divisor) of two ciphertexts  c1  and  c2  to determine the private key  k  used in a symmetric cryptosystem. 
Additionally, the script performs prime factorization of the GCD to identify the largest prime factor, which represents the private key.

## Features
	1.	GCD Calculation:
        Computes the GCD of two ciphertexts  c1  and  c2  using Python’s built-in math.gcd function.
	2.	Prime Factorization:
        Breaks the GCD into its prime factors using an iterative approach.
	3.	Validation of Manual Work:
        Automates the GCD computation and prime factorization to validate manual calculations performed using the Euclidean Algorithm.

## How It Works
1.	The script takes the two ciphertexts  c1  and  c2  as input:
	• c1 = 12849217045006222 
	• c2 = 6485880443666222 
2.	It calculates the GCD:
    GCD(c1, c2) = 174385766

3.	It performs prime factorization of the GCD:
    Prime factors of 174385766 = [2, 87192883]

4.	The private key  k  is the largest prime factor:
    k = 87192883

## How to Run
1.	Requirements:
	• Python 3.6 or above.
	• No additional libraries are required.
2.  Steps:
	• Save the script as main.py.
	• Open a terminal and navigate to the directory containing the script.
	• Run the script:
    ```bash
    python3 main.py
    ```
## Example Output:
Upon running the script, the following output will be displayed:
    ```bash
    GCD of ciphertexts: 174385766
    Prime factors of GCD: [2, 87192883]
    ```
# Conclusion
This script validates the manual calculation of the GCD and private key. The private key  k  is confirmed to be:
    k = 87192883


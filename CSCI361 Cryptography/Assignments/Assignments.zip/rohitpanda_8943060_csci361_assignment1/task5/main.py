"""
CSCI361 ASSIGNMENT 1 TASK 5
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
# A PYTHON SCRIPT TO VALIDATE MY MANUAL CALCULATION OF TASK 5

"""
TERMINAL OUTPUT:
(base) rohitpanda@Rohits-MBP task5 % python3 main.py
GCD of ciphertexts: 174385766
Prime factors of GCD: [2, 87192883]
"""

from math import gcd
from typing import Tuple

def find_prime_factors(n: int) -> list[int]:
    """Find all prime factors of a number."""
    factors = []
    d = 2
    while n > 1:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1
        if d * d > n:
            if n > 1:
                factors.append(n)
            break
    return factors

def find_private_key(c1: int, c2: int) -> Tuple[int, list[int]]:
    """
    Find the private key k given two ciphertexts.
    Returns the GCD and its prime factors.
    """
    # Calculate GCD of the two ciphertexts
    common_factor = gcd(c1, c2)
    
    # Find prime factors of the GCD
    prime_factors = find_prime_factors(common_factor)
    
    return common_factor, prime_factors

# Test with the given ciphertexts
c1 = 12849217045006222
c2 = 6485880443666222

gcd_result, factors = find_private_key(c1, c2)

print(f"GCD of ciphertexts: {gcd_result}")
print(f"Prime factors of GCD: {factors}")
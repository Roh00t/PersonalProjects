# Assignment 1, Task 3: Analysis of Substitution Cipher
## Description
This Python program analyzes the function  f(x) = x^k mod 26  for use as a substitution cipher where  k > 1  is the key and  x  is a plaintext letter. 
It tests whether the function can produce a valid one-to-one mapping for a given  k  and checks for collisions or missing outputs in the mapping.
## Features
	1.	Collision Detection:
The program identifies if multiple plaintext letters map to the same ciphertext letter, which makes  k  invalid as a substitution cipher key.
	2.	Mapping Table:
Prints the full mapping  x to f(x)  for each tested  k .
	3.	Missing Outputs:
Highlights any ciphertext letters (0–25) that are not mapped by the function for the tested  k .
	4.	Automatic Analysis:
Iterates through all possible  k  values  and determines valid  k  values that can be used for the cipher.

## How It Works
	1.	Testing Keys  k :
	• The program iterates through  k = 2  to  25 .
	• For each  k , it calculates  f(x) = x^k mod 26  for all  x in {0, 1,..., 25} .
	• Checks if the mapping is one-to-one (no collisions) and covers all ciphertext outputs (no missing outputs).
	2.	Collision Reporting:
	• If  f(x)  has collisions (multiple  x  mapping to the same  f(x) ), the program outputs the specific collisions.
	3.  Valid Key Identification:
	• The program prints the first valid  k  that satisfies the requirements for a substitution cipher and stops further testing.
	4.	Mapping Table Display:
	• For each  k , the program displays the full mapping  x to f(x) .

## Usage Instructions
	1.	Requirements:
	• Python 3.6 or above.
	• No additional libraries are required.
	2.	Running the Program:
        Save the file as task3_analysis.py and execute it using:
        ```bash
        python3 main.py
        ```
        The program automatically analyzes all valid  k  values and outputs the results to the console.

## Example Output
```bash
Testing k = 5:
No collisions found!
Complete mapping table for k = 5:
x   |  0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25
f(x)|  0  1  6 21 20  5  4 19  18 9 10 15 14 25 24 11 12 17 16  3  2  7  8 23 22 13

Testing k = 13:
Invalid mapping due to following collisions:
  Output 0 appears for multiple inputs: 0, 13
  Output 1 appears for multiple inputs: 1, 14
...
```
# Conclusion
The function  f(x) = x^k mod 26  can be used as a substitution cipher if and only if:
	1.	There are no collisions in the mapping.
	2.	The mapping is one-to-one and covers all ciphertext values.

The program effectively identifies valid  k  values and provides detailed analysis of the mapping behavior for each  k .

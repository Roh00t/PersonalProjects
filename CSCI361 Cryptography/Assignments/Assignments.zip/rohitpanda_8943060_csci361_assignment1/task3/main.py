"""
CSCI361 ASSIGNMENT 1 TASK 3
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""


def test_collisions(k, mod=26):
    """
    Test if f(x) = x^k mod 26 creates any collisions.
    Returns a dictionary containing collision information and mappings.
    """

    # Dictionary to store output -> list of inputs mappings

    output_to_inputs = {}
    
    # Test all possible input values (0-25)

    for x in range(mod):

        # Calculate f(x) = x^k mod 26 using pow() for correct modular exponentiation

        fx = pow(x, k, mod)
        
        # Add this input to the list of inputs that map to fx

        if fx in output_to_inputs:
            output_to_inputs[fx].append(x)
        else:
            output_to_inputs[fx] = [x]
    
    # Find all collisions (outputs with multiple inputs)

    collisions = {fx: inputs for fx, inputs in output_to_inputs.items() if len(inputs) > 1}
    
    # Create x -> f(x) mapping dictionary

    mappings = {x: pow(x, k, mod) for x in range(mod)}
    
    return {

        'has_collision': bool(collisions),
        'collisions': collisions,
        'mappings': mappings,
        'missing_outputs': set(range(mod)) - set(mappings.values())

    }

def print_mapping_table(k, result):

    """
    Print the complete mapping table for a given k value.
    """


    print(f"\nComplete mapping table for k = {k}:")
    print("x  | ", end="")
    for x in range(26):
        print(f"{x:2d} ", end="")
    print("\nf(x)| ", end="")
    for x in range(26):
        print(f"{result['mappings'][x]:2d} ", end="")
    print()

def analyze_cipher():
    """
    Analyze all possible k values and find collisions.
    """

    print("Analysis of f(x) = x^k mod 26 for k > 1")
    print("-" * 50)
    
    # Test k values from 2 up to 25

    for k in range(2, 26):
        print(f"\nTesting k = {k}:")
        result = test_collisions(k)
        
        if result['has_collision']:
            print("Invalid mapping due to following collisions:")
            for fx, inputs in result['collisions'].items():
                inputs_str = ", ".join(str(x) for x in inputs)
                print(f"  Output {fx} appears for multiple inputs: {inputs_str}")
            
            if result['missing_outputs']:
                print("Missing outputs:", sorted(result['missing_outputs']))
                
            print_mapping_table(k, result)
        else:
            print("No collisions found!")
            print_mapping_table(k, result)
    
    print("\nConclusion:")

    print("The function cannot be used as a cipher for k > 1")
    
    print("The function passes as a cipher for k = 5,7,11,13,17,19,23,25")

    print("The function fails as a cipher for some k > 1")

    print("When the cipher fails, each value of k either creates collisions or misses possible outputs,")

    print("violating the one-to-one mapping requirement for a valid cipher.")
    

if __name__ == "__main__":
    analyze_cipher()
"""
CSCI361 ASSIGNMENT 1 TASK 6
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
# Synchronous Cipher Implementation
## Overview
This Python implementation provides a stream cipher that operates on characters A-Z, with support for preserving spaces in messages. 
The program includes both encryption and decryption functionality.

## Technical Details

### Key Stream Generation
- First key (k₁) = (k⁷ + 2) mod 26
- Subsequent keys (kₙ) = (kₙ₋₁³ + n) mod 26
- Key must be in range 0-25

### Encryption
- Input: message string and key integer
- Output: encrypted string
- Formula: cᵢ = (mᵢ + kᵢ) mod 26

### Decryption
- Input: ciphertext string and key integer
- Output: decrypted string
- Formula: mᵢ = (cᵢ - kᵢ) mod 26

## Program Functions

### generate_key_stream(key: int, length: int) -> list[int]
- Generates the key stream sequence
- Parameters:
  - key: integer between 0-25
  - length: number of keys needed
- Returns: list of key stream values

### encrypt(message: str, key: int) -> str
- Encrypts a message
- Parameters:
  - message: string to encrypt
  - key: integer between 0-25
- Returns: encrypted string

### decrypt(ciphertext: str, key: int) -> str
- Decrypts a ciphertext
- Parameters:
  - ciphertext: string to decrypt
  - key: integer between 0-25
- Returns: decrypted string

## Usage Examples
```bash
Encrypt the message I LOVE WOLLONGONG with key = 7
Original message: I LOVE WOLLONGONG
Encrypted: D SWR XXWLUZDGBOW
 
Decrypt the ciphertext MQJJ with key = 7

Ciphertext: MQJJ
Decrypted: RJBN
```
```python
# Encryption
message = "I LOVE WOLLONGONG"
key = 7
encrypted = encrypt(message, key)

# Decryption
ciphertext = "MQJJ"
decrypted = decrypt(ciphertext, key)
```

## Features
- Preserves spaces in messages
- Case-insensitive input
- Ignores non-alphabetic characters
- Input validation for key values
- Modular design for easy integration

## Implementation Notes
- All alphabetic characters are converted to uppercase
- Spaces are preserved in their original positions
- Invalid characters are silently ignored
- Empty input returns empty output
- Key must be between 0 and 25 inclusive

## Error Handling
- Raises ValueError for invalid key values
- Gracefully handles empty strings
- Safely processes messages with special characters

## Test Cases
1. Encryption test:
   - Input: "I LOVE WOLLONGONG" with key=7
   
2. Decryption test:
   - Input: "MQJJ" with key=7

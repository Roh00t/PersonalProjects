"""
CSCI361 ASSIGNMENT 1 TASK 6
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""


def generate_key_stream(key: int, length: int) -> list[int]:
    """
    Generate key stream based on the given key and required length.
    k1 = (k^7 + 2) mod 26
    kn = (k_(n-1)^3 + n) mod 26
    """
    if not 0 <= key <= 25:
        raise ValueError("Key must be between 0 and 25")
    
    key_stream = []
    # Generate k1
    k1 = (pow(key, 7) + 2) % 26
    key_stream.append(k1)
    
    # Generate subsequent keys
    for n in range(2, length + 1):
        kn = (pow(key_stream[-1], 3) + n) % 26
        key_stream.append(kn)
    
    return key_stream

def char_to_num(char: str) -> int:
    """Convert character to number (A=0, B=1,..., Z=25)"""
    return ord(char.upper()) - ord('A')

def num_to_char(num: int) -> str:
    """Convert number to character (0=A, 1=B,..., 25=Z)"""
    return chr((num % 26) + ord('A'))

# Encrypt a message using the synchronous cipher.
def encrypt(message: str, key: int) -> str:


    # Filter message to only include valid characters and spaces

    processed_msg = []
    spaces = []  # Track space positions
    
    for i, char in enumerate(message):
        if char.isalpha():
            processed_msg.append(char)
        elif char == ' ':
            spaces.append(len(processed_msg))
    
    if not processed_msg:
        return ""
    
    # Generate key stream for the message length

    key_stream = generate_key_stream(key, len(processed_msg))
    
    # Encrypt each character

    ciphertext = []
    for i, char in enumerate(processed_msg):
        m = char_to_num(char)
        c = (m + key_stream[i]) % 26
        ciphertext.append(num_to_char(c))
    
    # Reinsert spaces

    for pos in spaces:
        ciphertext.insert(pos, ' ')
    
    return ''.join(ciphertext)

def decrypt(ciphertext: str, key: int) -> str:

    """
    Decrypt a ciphertext using the synchronous cipher.
    """

    # Filter ciphertext to only include valid characters and spaces

    processed_cipher = []
    spaces = []  # Track space positions
    
    for i, char in enumerate(ciphertext):
        if char.isalpha():
            processed_cipher.append(char)
        elif char == ' ':
            spaces.append(len(processed_cipher))
    
    if not processed_cipher:
        return ""
    
    # Generate key stream for the ciphertext length


    key_stream = generate_key_stream(key, len(processed_cipher))
    
    # Decrypt each character


    plaintext = []
    for i, char in enumerate(processed_cipher):
        c = char_to_num(char)
        m = (c - key_stream[i]) % 26
        plaintext.append(num_to_char(m))
    
    # Reinsert spaces


    for pos in spaces:
        plaintext.insert(pos, ' ')
    
    return ''.join(plaintext)

# Test the implementation


if __name__ == "__main__":

    # Encryption

    print("Encrypt the message I LOVE WOLLONGONG with key = 7")
    message = "I LOVE WOLLONGONG"
    key = 7
    encrypted = encrypt(message, key)
    print(f"Original message: {message}")
    print(f"Encrypted: {encrypted}")
    print(" ")

    # Decryption

    print("Decrypt the ciphertext MQJJ with key = 7")
    ciphertext = "MQJJ"
    decrypted = decrypt(ciphertext, key)
    print(f"\nCiphertext: {ciphertext}")
    print(f"Decrypted: {decrypted}")
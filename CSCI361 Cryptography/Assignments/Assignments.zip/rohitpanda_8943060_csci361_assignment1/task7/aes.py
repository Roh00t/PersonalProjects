"""
CSCI361 ASSIGNMENT 1 TASK 7
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""

import sys
import os
# Add user site-packages to Python path

user_site_packages = os.path.expanduser('~/Library/Python/3.8/lib/python/site-packages')
sys.path.append(user_site_packages)

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

def encrypt_image(input_file, output_file, key, mode="CBC"):
    """
    Encrypts a BMP image using AES in specified mode (CBC or CTR).
    Preserves the 54-byte BMP header.
    """

    # Read the input image


    with open(input_file, "rb") as f:
        image_data = f.read()
    
    # Split header and body


    header = image_data[:54]
    body = image_data[54:]
    
    # Initialize cipher based on mode

    if mode == "CBC":
        cipher = AES.new(key, AES.MODE_CBC)
        # Save the IV for decryption

        iv = cipher.iv
    else:  # CTR mode
        cipher = AES.new(key, AES.MODE_CTR)
        # Save the nonce for decryption

        iv = cipher.nonce
    
    # Pad and encrypt the body

    if mode == "CBC":
        encrypted_body = cipher.encrypt(pad(body, AES.block_size))
    else:
        # CTR mode doesn't need padding

        encrypted_body = cipher.encrypt(body)
    
    # Write header, IV/nonce, and encrypted body
    
    with open(output_file, "wb") as f:
        f.write(header + iv + encrypted_body)
    
    print(f"Image encrypted using AES-{mode}")

def decrypt_image(input_file, output_file, key, mode="CBC"):
    """
    Decrypts a BMP image that was encrypted using AES in specified mode.
    """
    # Read the encrypted image
    with open(input_file, "rb") as f:
        data = f.read()
    
    # Split the components based on mode
    header = data[:54]
    if mode == "CBC":
        iv = data[54:70]  # 16 bytes IV for CBC
        encrypted_body = data[70:]
    else:  # CTR mode
        iv = data[54:62]  # 8 bytes nonce for CTR
        encrypted_body = data[62:]
    
    # Initialize cipher based on mode
    if mode == "CBC":
        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        # Decrypt and remove padding
        decrypted_body = unpad(cipher.decrypt(encrypted_body), AES.block_size)
    else:  # CTR mode
        cipher = AES.new(key, AES.MODE_CTR, nonce=iv)
        # CTR mode doesn't use padding
        decrypted_body = cipher.decrypt(encrypted_body)
    
    # Write the decrypted image
    with open(output_file, "wb") as f:
        f.write(header + decrypted_body)
    
    print(f"Image decrypted using AES-{mode}")

def corrupt_byte(input_file, output_file, position):
    """
    Corrupts a single byte in the encrypted image at specified position.
    Position is relative to the start of the encrypted data (after header + IV).
    """
    with open(input_file, "rb") as f:
        data = bytearray(f.read())
    
    # Actual position = header (54) + IV (16) + specified position
    actual_position = 70 + position
    
    # Set the byte to 0
    data[actual_position] = 0
    
    with open(output_file, "wb") as f:
        f.write(data)
    
    print(f"Corrupted byte at position {position} in encrypted data")

def main():
    # Fixed test key (16 bytes)
    key = b"TestKey123456789"
    
    # Test both CBC and CTR modes
    for mode in ["CBC", "CTR"]:
        print(f"\nTesting AES-{mode} mode:")
        
        # 1. Encrypt the original image
        encrypt_image("input.bmp", f"encrypted_{mode}.bmp", key, mode)
        
        # 2. Create a corrupted version
        corrupt_byte(f"encrypted_{mode}.bmp", f"corrupted_{mode}.bmp", 1000)
        
        # 3. Decrypt the corrupted version
        decrypt_image(f"corrupted_{mode}.bmp", f"decrypted_{mode}.bmp", key, mode)

if __name__ == "__main__":
    main()
"""
CSCI361 ASSIGNMENT 1 TASK 7
STUDENT NAME: ROHIT PANDA
STUDENT UOWID: 8943060
"""
NOTE: cd into task7 then run the program under the virtual environment.

# Task Seven: Comparing block cipher modes (2 marks)
This Python script demonstrates the encryption and decryption of a BMP image using the AES cipher in both CBC and CTR modes.

## Key Features
1. Encrypts and decrypts a BMP image, preserving the 54-byte header.
2. Allows corrupting a single byte in the encrypted data to demonstrate the impact on decryption.
3. Compares the behavior of AES-CBC and AES-CTR modes when dealing with ciphertext corruption.

## Usage
1. Place the original image file `input.bmp` in the same directory as the script.
2. Run the script using Python:

   ```
   python aes.py
   ```

   This will:
   - Encrypt the image using both AES-CBC and AES-CTR modes, saving the encrypted files as `encrypted_CBC.bmp` and `encrypted_CTR.bmp`.
   - Corrupt a single byte in the middle of the encrypted data for each mode, saving the corrupted files as `corrupted_CBC.bmp` and `corrupted_CTR.bmp`.
   - Decrypt the corrupted files and save the results as `decrypted_CBC.bmp` and `decrypted_CTR.bmp`.

3. Observe the differences in the decrypted images between the CBC and CTR modes when a single byte is corrupted in the ciphertext.
## Key Dependencies

- `pycryptodome` library for AES encryption/decryption

## Explanation
The script defines the following functions:

1. `encrypt_image(input_file, output_file, key, mode="CBC")`: Encrypts the input image file using the specified AES mode (CBC or CTR).
2. `decrypt_image(input_file, output_file, key, mode="CBC")`: Decrypts the encrypted image file using the specified AES mode.
3. `corrupt_byte(input_file, output_file, position)`: Corrupts a single byte in the encrypted data at the specified position.
4. `main()`: The entry point that tests both AES-CBC and AES-CTR modes.

The main difference between CBC and CTR modes is how they handle ciphertext corruption:

- In AES-CBC mode, a single ciphertext block corruption affects the decryption of all subsequent blocks.
- In AES-CTR mode, a single ciphertext block corruption only affects the decryption of that specific block.

This can be observed by comparing the decrypted images when a single byte is corrupted in the encrypted data.

